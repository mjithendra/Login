Steps to run this program:
1. Download and Install JRE 8 x64 (re-8u192-windows-x64.exe) from https://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html 
2. Download and install eclipse from https://www.eclipse.org/downloads/download.php?file=/oomph/epp/2018-09/Ra/eclipse-inst-win64.exe
3. Create a new Java Project with name longestword in eclipse.
4. Download the project from github and UnZip it and then Import Project from filesystem using File -> Import... in  eclipse
5. Open file from longestword -> src -> com.longestword.test - > LongestWordTest and then Run -> Run as -> JUnit Test.
