package com.longestword;

import java.util.List;

/*
 * Class to hold the data - longest word in a sentence and the length of the longest word. 
 */
public class ResponseData {
	
	/*
	 * length of longest word in a sentence
	 */
	private int lengthWord;
	
	/*
	 * longest word in a sentence
	 */
	private List<String> longestWords;
	
	/*
	 * Get the length of longest word in a  sentence
	 */
	public int getLengthWord() {
		return lengthWord;
	}
	
	/*
	 * Set the length of longest word in a  sentence
	 */
	public void setLengthWord(int lengthWord) {
		this.lengthWord = lengthWord;
	}
	
	/*
	 * Get the longest word in a  sentence
	 */
	public List<String> getLongestWords() {
		return longestWords;
	}
	
	/*
	 * Set the length of longest word in a  sentence
	 */
	public void setLongestWords(List<String> longestWords) {
		this.longestWords = longestWords;
	}	
}
