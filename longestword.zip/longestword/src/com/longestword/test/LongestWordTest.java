package com.longestword.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.longestword.LongestWord;
import com.longestword.ResponseData;

class LongestWordTest {
	
	public ResponseData getSingleWord(String testStr) {
		LongestWord longestWord = new LongestWord();
		ResponseData resdata = longestWord.getLongestWordAndLength(testStr, "[,?.@:\\s]+", false);
		return resdata;
	}
	
	public ResponseData getMultipleWords(String testStr) {
		LongestWord longestWord = new LongestWord();
		ResponseData resdata = longestWord.getLongestWordAndLength(testStr, "[,?.@:\\s]+", true);
		return resdata;
	}

	@Test
	void testStringWithSpaces() {
		String testStr = "Hi, this is a test sentence to find the longest word.";
		ResponseData resdata = getSingleWord(testStr);
		assertEquals("sentence", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertEquals(8, resdata.getLengthWord(), "Longest Word Length Mismatch!");
		assertNotEquals("longest", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertNotEquals("word", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
	}
	
	@Test
	void testStringWithSeparatorChars() {
		String testStr = "Hello, How are you gefr��ig-5645? \n\nabcdefg\n\t\nhello@abcd.com";
		ResponseData resdata = getSingleWord(testStr);
		assertEquals("gefr��ig-5645", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertEquals(13, resdata.getLengthWord(), "Longest Word Length Mismatch!");
	}
	
	@Test
	void testStringModifySeparatorChars() {
		String testStr = "Hello, How are you gefr��ig-5645? \n\nabcdefg\n\t\nhello@abcd.com";
		LongestWord longestWord = new LongestWord();
		ResponseData resdata = longestWord.getLongestWordAndLength(testStr, "[,?:\\s]+", false);
		assertEquals("hello@abcd.com", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertEquals(14, resdata.getLengthWord(), "Longest Word Length Mismatch!");
	}
	
	@Test
	void testEmptyString() {
		String testStr = null;
		ResponseData resdata = getSingleWord(testStr);
		assertEquals(0, resdata.getLongestWords().size(), "Longest Word Mismatch!");
		assertEquals(0, resdata.getLengthWord(), "Longest Word Length Mismatch!");
		
		testStr = "";
		resdata = getSingleWord(testStr);
		assertEquals(0, resdata.getLongestWords().size(), "Longest Word Mismatch!");
		assertEquals(0, resdata.getLengthWord(), "Longest Word Length Mismatch!");
	}
	
	@Test
	void testMultiStringWithSpaces() {
		String testStr = "Hi, this is a test sentence to find the longgest word.";
		ResponseData resdata = getMultipleWords(testStr);
		System.out.println(resdata.getLongestWords());
		assertEquals("sentence", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertEquals(8, resdata.getLengthWord(), "Longest Word Length Mismatch!");
		assertEquals("longgest", resdata.getLongestWords().get(1), "Longest Word Mismatch!");
		assertNotEquals("word", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
	}
	
	@Test
	void testMultiStringWithSeparatorChars() {
		String testStr = "Hello, How are you gefr��ig-5645? \n\nabcdefghijklm\n\t\nhello@abcd.com";
		ResponseData resdata = getMultipleWords(testStr);
		System.out.println(resdata.getLongestWords());
		assertEquals("gefr��ig-5645", resdata.getLongestWords().get(0), "Longest Word Mismatch!");
		assertEquals(13, resdata.getLengthWord(), "Longest Word Length Mismatch!");
		assertEquals("abcdefghijklm", resdata.getLongestWords().get(1), "Longest Word Mismatch!");
	}
}
