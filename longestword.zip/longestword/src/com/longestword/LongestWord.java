package com.longestword;

import java.util.ArrayList;
import java.util.List;

/*
 * This class calculates the longest word and its length in a sentence.
 * Definition of a word is assumed to be as:
 * 	A group of characters excluding these - , ? . @ space tab newline.
 *  New characters can be added in the provided constant to modify this definition.
 *  Will need to select these characters carefully, as the definition can become
 *  ambiguous, like:
 *  	"abc@xyz.com" can also be considered as word (e-mail id), if @ is removed as separator.
 *  	"doesn't" can be considered as word, if the quote is excluded.
 *  	"Please say 'Hello'" - In this sentence, Hello can be considered as word if the quote is 
 *  	included as separator, else 'Hello' will be considered as word.
 *  
 *  This implementation supports international characters as well.
 *  If there are multiple longest words of the same length, only the first found word is shown.
 *  To show all the words of the same length, change the configuration constant SHOW_ALL_WORDS.
 * 	
 */
public class LongestWord {
	
	/*
	 * Constant Configuration to define the word boundaries/separators using reg-exp.
	 */
	static final String WORD_SEPARATORS_REGEX = "[,?.@:\\s]+";
	/*
	 * Configuration to show all the words of same length or just the first found word.
	 */
	static final boolean SHOW_ALL_WORDS = false;
	
	/*
	 * This method calculates the longest word and its length in a given sentence.	 
	 * @return class ResponseData with longest word and its length
	 * @param sentence - text to find the longest word from
	 * @param wordSeparators - define word separators
	 * @param showAllWords - show all words of same length or not
	 */
	public ResponseData getLongestWordAndLength(String sentence, String wordSeparators, 
			boolean showAllWords) {
		ResponseData resdata = new ResponseData();
		if (sentence == null || sentence.length() == 0) {
			List<String> longestWords = new ArrayList<String>();
			resdata.setLengthWord(0);
			resdata.setLongestWords(longestWords);
			return resdata;
		} else {
			String[] words = sentence.split(wordSeparators);
			int longestLength = 0;
			List<String> longestWords = new ArrayList<String>();
			for (String word : words) {
				int wordLen = word.toCharArray().length;//.length();
				if (wordLen > longestLength) {
					longestWords = new ArrayList<String>();	
					longestWords.add(word);
					longestLength = wordLen;
				} else if (wordLen == longestLength) {
					if (showAllWords || longestWords.size() == 0) {
						longestWords.add(word);
					}				
				}
			}
			resdata.setLengthWord(longestLength);
			resdata.setLongestWords(longestWords);
			return resdata;
		}
	}
	
	/*
	 * main class just to run and test the program
	 */
	public static void main(String[] args) {
		String sentence = "Hello, How are you \n\nabcdefg\n\t\nhello@abcd.com gefräßig-5645?";
		LongestWord clz = new LongestWord();
		ResponseData resdata = clz.getLongestWordAndLength(sentence, WORD_SEPARATORS_REGEX, 
										SHOW_ALL_WORDS);
		System.out.println(resdata.getLengthWord());
		if (SHOW_ALL_WORDS) {
			System.out.println(resdata.getLongestWords());
		} else {
			System.out.println(resdata.getLongestWords().get(0));
		}
	}

}
